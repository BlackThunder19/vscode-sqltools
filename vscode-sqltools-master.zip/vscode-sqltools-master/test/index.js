module.exports = require('./config/jest-test-runner.js');
