If(db_id(N'test_db') IS NULL)
    BEGIN
        CREATE DATABASE [test_db]
    END;
GO
USE test_db;
GO
