SELECT 1 as one from dual;

SELECT 2 as two from dual;
