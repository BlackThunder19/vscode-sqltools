SELECT * FROM personal_data.contacts;

SELECT now() FROM system.local;
