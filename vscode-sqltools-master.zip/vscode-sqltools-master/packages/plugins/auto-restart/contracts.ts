export const ExitCalledNotification = 'AutoRestart/exitCalled';
