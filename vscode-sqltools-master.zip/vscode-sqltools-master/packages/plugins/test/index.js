const testRunner = require('../../../test');

module.exports = testRunner;