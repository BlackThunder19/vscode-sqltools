import { SQLToolsLanguageClient } from './client';

export default SQLToolsLanguageClient