import React from 'react';
import { render } from 'react-dom';
import SettingsScreen from './Settings/Screen';

render(<SettingsScreen />, document.getElementById('root'));
