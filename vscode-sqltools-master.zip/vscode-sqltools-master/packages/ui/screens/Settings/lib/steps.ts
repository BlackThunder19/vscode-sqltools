export enum Step {
  CONNECTION_TYPE = 1,
  CONNECTION_INFO = 2,
  CONNECTION_CREATED = 3,
}

export const totalSteps = 3;