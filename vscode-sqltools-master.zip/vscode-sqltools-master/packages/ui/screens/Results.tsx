import React from 'react';
import { render } from 'react-dom';
import ResultsScreen from './Results/Screen';

render(<ResultsScreen />, document.getElementById('root'));
