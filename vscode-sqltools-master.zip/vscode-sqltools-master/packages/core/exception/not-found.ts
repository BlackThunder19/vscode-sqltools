import GenericException from './generic';
export class NotFoundException extends GenericException { }

export default NotFoundException;
