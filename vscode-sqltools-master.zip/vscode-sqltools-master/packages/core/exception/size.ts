import GenericException from './generic';

export class SizeException extends GenericException {}
