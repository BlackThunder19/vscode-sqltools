export default class GenericException extends Error {
}
