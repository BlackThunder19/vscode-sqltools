import { sync as commandExists } from 'command-exists';

export default commandExists;